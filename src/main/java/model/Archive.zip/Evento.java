package model;

import java.util.ArrayList;
import java.util.List;

public class Evento {
    private String titolo;
    private String descrizione;
    private int maxCapienza;
    private List<Ospite> ospiti;
    private List<Visitatore> visitatori;

    public Evento(String titolo, String descrizione, int maxCapienza) {
        this.titolo = titolo;
        this.descrizione = descrizione;
        this.maxCapienza = maxCapienza;
        this.ospiti = new ArrayList<>();
        this.visitatori = new ArrayList<>();
    }

    public void addOspite(Ospite o) {
        ospiti.add(o);
    }

    public void addVisitatore(Visitatore v) {
        visitatori.add(v);
    }

    public boolean isCapienzaFull() {
        return (ospiti.size() + visitatori.size()) >= maxCapienza;
    }

    public String getTitolo() {
        return titolo;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public int getMaxCapienza() {
        return maxCapienza;
    }

    public List<Ospite> getOspiti() {
        return ospiti;
    }

    public List<Visitatore> getVisitatori() {
        return visitatori;
    }
}